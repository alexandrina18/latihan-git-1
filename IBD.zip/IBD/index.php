<?php
session_start();
require_once "db.php";

// kalau SUDAH login → langsung ke dashboard
if (isset($_SESSION["user"])) {
    header("Location: dashboard.php");
    exit;
}

$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user = $mysqli->real_escape_string($_POST["username"]);
    $pass = $mysqli->real_escape_string($_POST["password"]);

    $sql = "SELECT * FROM tabel_user WHERE username='$user' AND password='$pass'";
    $res = $mysqli->query($sql);

    if ($res && $res->num_rows === 1) {
        $_SESSION["user"] = $user;
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Login gagal!";
    }
}
?>
