<?php
session_start();
if(!isset($_SESSION["user"])) { header("Location: index.php"); exit; }
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Dashboard</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
<header>
  <h1>Nusapocket</h1>
  <nav>
    <a href="pinjaman.php">Pinjaman</a>
    <a href="transaksi.php">Transaksi</a>
    <a href="notif.php">Notifikasi</a>
    <a href="faq.php">FAQ</a>
    <a href="laporan.php">Laporan SHU</a>
    <a href="logout.php">Logout</a>
  </nav>
</header>
<main>
  <p>Selamat datang, <?= htmlspecialchars($_SESSION["user"]) ?>!</p>
</main>
</body>
</html>
